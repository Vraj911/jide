import { readFile, writeFile } from 'node:fs/promises';
import { createRequire } from 'node:module';
import { formatErrors } from '../errors.js';

const require = createRequire(import.meta.url);
const compiler = require('../../lib/jpp/compiler.js');

export async function buildCommand(argv) {
    // Dynamically import the compiler (ESM) – no require()
    const { default: compile } = await import('../../lib/jpp/compiler.js');
    if (!result.success) {
        console.error('Compilation failed:\n' + formatErrors(result.errors));
        process.exit(1);
    }
    await writeFile(argv.out, result.code, 'utf8');
    console.log(`✅ Built ${argv.out}`);
    process.exit(0);
}
