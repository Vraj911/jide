import { readFile } from 'node:fs/promises';
import { formatErrors } from '../errors.js';

/**
 * jpp run <file.jpp>
 *   • Compile the J++ source using the black‑box compiler.
 *   • If compilation fails, print formatted errors and exit 1.
 *   • On success, execute the generated JavaScript in a sandboxed VM.
 */
export async function runCommand(argv) {
    try {
        const { compile } = await import('../../lib/jpp/compiler.js');
        const source = await readFile(argv.file, 'utf8');
        const result = compile(source);
        if (!result.success) {
            console.error('Compilation failed:\n' + formatErrors(result.errors));
            process.exit(1);
        }
        const { Script, createContext } = await import('node:vm');
        const context = createContext({ console, require, process, setTimeout, setInterval, clearTimeout, clearInterval });
        const script = new Script(result.code, { filename: argv.file + '.js' });
        const output = script.runInContext(context);
        if (output !== undefined) console.log(output);
        process.exit(0);
    } catch (err) {
        console.error('Runtime error:', err);
        process.exit(1);
    }
}
