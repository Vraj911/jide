import yargs from 'yargs';
import { hideBin } from 'yargs/helpers';
import { runCommand } from './commands/run.js';
import { checkCommand } from './commands/check.js';
import { buildCommand } from './commands/build.js';
import { astCommand } from './commands/ast.js';
import { fmtCommand } from './commands/fmt.js';

yargs(hideBin(process.argv))
    .scriptName('jpp')
    .usage('Usage: $0 <command> [options]')
    .command('run <file>', 'Compile and execute a J++ program', (y) =>
        y.positional('file', { type: 'string', describe: 'J++ source file' })
        , runCommand)
    .command('check <file>', 'Compile and type‑check only', (y) =>
        y.positional('file', { type: 'string', describe: 'J++ source file' })
        , checkCommand)
    .command('build <file>', 'Compile to JavaScript', (y) =>
        y.positional('file', { type: 'string', describe: 'J++ source file' })
            .option('out', {
                alias: 'o',
                type: 'string',
                demandOption: true,
                describe: 'Output JavaScript file'
            })
        , buildCommand)
    .command('ast <file>', 'Print the AST as JSON', (y) =>
        y.positional('file', { type: 'string', describe: 'J++ source file' })
        , astCommand)
    .command('fmt <file>', 'Format source code (deterministic whitespace)', (y) =>
        y.positional('file', { type: 'string', describe: 'J++ source file' })
        , fmtCommand)
    .demandCommand(1, 'You need at least one command')
    .help()
    .strict()
    .parse();
