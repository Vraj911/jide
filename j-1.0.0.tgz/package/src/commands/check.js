import { readFile } from 'node:fs/promises';
import { createRequire } from 'node:module';
import { formatErrors } from '../errors.js';

const require = createRequire(import.meta.url);
const compiler = require('../../lib/jpp/compiler.js');

export async function checkCommand(argv) {
    const source = await readFile(argv.file, 'utf8');
    const result = compiler.compile(source);
    if (!result.success) {
        console.error('Type‑check errors:\n' + formatErrors(result.errors));
        process.exit(1);
    }
    console.log('✅ No type‑checking errors.');
    process.exit(0);
}
