import { readFile, writeFile } from 'node:fs/promises';
import { createRequire } from 'node:module';
import { formatErrors } from '../errors.js';

const require = createRequire(import.meta.url);
const compiler = require('../../lib/jpp/compiler.js'); // black‑box

export async function runCommand(argv) {
    try {
        const source = await readFile(argv.file, 'utf8');
        const result = compiler.compile(source);
        if (!result.success) {
            console.error('Compilation failed:\n' + formatErrors(result.errors));
            process.exit(1);
        }
        // Execute generated JS safely using Node's vm module
        const { Script, createContext } = await import('node:vm');
        const context = createContext({ console, require, process, setTimeout, setInterval, clearTimeout, clearInterval });
        const script = new Script(result.code, { filename: argv.file + '.js' });
        const output = script.runInContext(context);
        if (output !== undefined) console.log(output);
        process.exit(0);
    } catch (err) {
        console.error('Runtime error:', err);
        process.exit(1);
    }
}
