import { readFile } from 'node:fs/promises';
import { createRequire } from 'node:module';
import { formatErrors } from '../errors.js';

const require = createRequire(import.meta.url);
const compiler = require('../../lib/jpp/compiler.js');

export async function astCommand(argv) {
    const source = await readFile(argv.file, 'utf8');
    const result = compiler.compile(source);
    if (!result.success) {
        console.error('Cannot generate AST – compilation failed:\n' + formatErrors(result.errors));
        process.exit(1);
    }
    console.log(JSON.stringify(result.ast, null, 2));
    process.exit(0);
}
